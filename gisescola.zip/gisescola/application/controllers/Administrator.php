<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Administrator extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_Munisipio');
    }
    public function index()
    {
        $this->load->model('M_Escola', 'escola');
        $escola = $this->M_Escola->get_escola();
        $data = array('escola' => $escola);

        $data['titlu'] = 'Administrator || Dashboard';
        $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('template/header', $data);
        $this->load->view('template/navbar');
        $this->load->view('template/sidebar', $data);
        $this->load->view('administrator/dashboard', $data);
        $this->load->view('template/footer');
    }

    public function msp()
    {

        $municipio = $this->M_Munisipio->get_munisipio();
        $dadus = array('munisipio' => $municipio);
        $data['titlu'] = 'Administrator || Dashboard';
        $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('template/header', $data);
        $this->load->view('template/navbar');
        $this->load->view('template/sidebar', $data);
        $this->load->view('administrator/munisipio/msp', $dadus);
        $this->load->view('template/footer');
    }

    public function aumentamsp()
    {
        $this->form_validation->set_rules('munisipio', 'Munisipio', 'required|trim|is_unique[tbl_munisipio.munisipio]', ['is_unique' => 'Municipio registo tiha ona']);
        // $this->form_validation->set_rules('foto', 'Nivel', 'requider|trim');

        $this->form_validation->set_message('required', 'Favor Prienxe %s labele husik mamuk');
        if ($this->form_validation->run() == false) {
            $data['titlu'] = 'Administrator | Munisipio';
            $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar', $data);
            $this->load->view('administrator/munisipio/aumentamsp');
            $this->load->view('template/footer');
        } else {

            $data = [
                'munisipio ' => htmlspecialchars($this->input->post('munisipio', true))
                //'icon' => htmlspecialchars($this->input->post('icon', true))

            ];
            $this->M_Munisipio->aumentamsp($data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Dadus municipio halot ho succeso!</div>');
            redirect('administrator/msp');
        }
    }

    public function editmsp($id_munisipio)
    {
        $this->form_validation->set_rules('munisipio', 'Munisipio', 'required|trim|is_unique[tbl_munisipio.munisipio]', ['is_unique' => 'Municipio registo tiha ona']);
        // $this->form_validation->set_rules('foto', 'Nivel', 'requider|trim');

        $this->form_validation->set_message('required', 'Favor Prienxe %s labele husik mamuk');
        if ($this->form_validation->run() == false) {
            $data['titlu'] = 'Administrator | Munisipio';
            $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
            $munisipio = $this->M_Munisipio->detail($id_munisipio);
            $dadus = array('munisipio' => $munisipio,);
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar', $data);
            $this->load->view('administrator/munisipio/editmsp', $dadus);
            $this->load->view('template/footer');
        } else {

            $data = [
                'id_munisipio' => $id_munisipio,
                'munisipio ' => htmlspecialchars($this->input->post('munisipio', true))
                //'icon' => htmlspecialchars($this->input->post('icon', true))

            ];
            $this->M_Munisipio->editmsp($data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Dadus municipio halot ho succeso!</div>');
            redirect('administrator/msp');
        }
    }

    public function hamosmsp($id_municipio)
    {
        $data = array('id_munisipio' => $id_municipio);
        $this->M_Munisipio->hamosmsp($data); // Panggil fungsi delete dari model
        $this->session->set_flashdata('message', '<div class="alert alert-danger " role="alert " > Dadus Hamos ho succeso!</div>');

        redirect('administrator/msp');
    }


    public function pst()
    {
        $this->load->model('M_Posto', 'posto');
        $posto = $this->M_Posto->get_Posto();
        $data = array('posto' => $posto);
        $data['titlu'] = 'Administrator | Posto';
        $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('template/header', $data);
        $this->load->view('template/navbar');
        $this->load->view('template/sidebar', $data);
        $this->load->view('administrator/posto/pst', $data);
        $this->load->view('template/footer');
    }

    public function aumentapst()
    {
        $this->form_validation->set_rules('posto', 'posto', 'required|trim|is_unique[tbl_posto.posto]', ['is_unique' => 'Posto registo tiha ona']);
        $this->form_validation->set_rules('id_munisipio', 'Munisipio', 'required|trim');
        $this->form_validation->set_message('required', 'Favor Prienxe %s labele husik mamuk');
        if ($this->form_validation->run() == false) {
            $munisipio = $this->M_Munisipio->get_munisipio();
            $dadus = array(

                'munisipio' => $munisipio,


            );
            $data['titlu'] = 'Administrator | Munisipio';
            $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar', $data);
            $this->load->view('administrator/posto/aumentapst', $dadus);
            $this->load->view('template/footer');
        } else {

            $data = [
                'id_munisipio' => htmlspecialchars($this->input->post('id_munisipio', true)),
                'posto ' => htmlspecialchars($this->input->post('posto', true))


            ];
            $this->M_Posto->aumentapst($data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Dadus municipio halot ho succeso!</div>');
            redirect('administrator/pst');
        }
    }

    public function editpst($id_munisipio)
    {
        $this->form_validation->set_rules('posto', 'posto', 'required|trim|is_unique[tbl_posto.posto]', ['is_unique' => 'Posto registo tiha ona']);
        $this->form_validation->set_rules('id_munisipio', 'Munisipio', 'required|trim');
        if ($this->form_validation->run() == false) {
            $munisipio = $this->M_Munisipio->get_munisipio();
            $posto = $this->M_Posto->detail($id_munisipio);
            $dadus = array(

                'munisipio' => $munisipio,
                'posto' => $posto,


            );
            $data['titlu'] = 'Administrator | Munisipio';
            $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar', $data);
            $this->load->view('administrator/posto/editpst', $dadus);
            $this->load->view('template/footer');
        } else {

            $data = [
                'id_munisipio' => $id_munisipio,
                'id_munisipio' => htmlspecialchars($this->input->post('id_munisipio', true)),
                'posto ' => htmlspecialchars($this->input->post('posto', true))


            ];
            $this->M_Posto->editpst($data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Dadus municipio halot ho succeso!</div>');
            redirect('administrator/pst');
        }
    }

    public function hamospst($id_munisipio)
    {
        $data = array('id_munisipio' => $id_munisipio);
        $this->M_Posto->hamospst($data); // Panggil fungsi delete dari model
        $this->session->set_flashdata('message', '<div class="alert alert-danger " role="alert " > Dadus Hamos ho succeso!</div>');

        redirect('administrator/pst');
    }

    // Controller nivel

    public function nivel()
    {
        $this->load->model('M_Nivel', 'nivel');
        $nivel = $this->M_Nivel->get_nivel();
        $data = array('nivel' => $nivel);
        $data['titlu'] = 'Administrator || Dashboard';
        $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('template/header', $data);
        $this->load->view('template/navbar');
        $this->load->view('template/sidebar');
        $this->load->view('administrator/nivel/nivel', $data);
        $this->load->view('template/footer');
    }

    public function aumentanvl()
    {
        $this->form_validation->set_rules('nivel_ensino', 'nivel', 'required|trim|is_unique[tbl_nivel.nivel_ensino]', ['is_unique' => 'Posto registo tiha ona']);
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required|trim');
        $this->form_validation->set_message('required', 'Favor Prienxe %s labele husik mamuk');
        if ($this->form_validation->run() == false) {

            $data['titlu'] = 'Administrator | Nivel Ensino';
            $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();

            $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar', $data);
            $this->load->view('administrator/nivel/aumentanvl');
            $this->load->view('template/footer');
        } else {

            $nivel_ensino  = htmlspecialchars($this->input->post('nivel_ensino', true));
            $deskripsi = htmlspecialchars($this->input->post('deskripsi', true));
            $icon = $_FILES['icon']['name'];
            if ($icon = '') {
            } else {
                $config['upload_path']          = './assets/img/marker/';
                $config['allowed_types']        = 'jpg|png';

                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('icon')) {
                    $this->session->set_flashdata('message', '<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>Atensaun</strong>Imagen Upload Filha.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>');
                    redirect('administrator/aumentanvl');
                } else {
                    $icon = $this->upload->data('file_name');
                }
            }

            $data = array(
                'nivel_ensino ' => $nivel_ensino,
                'deskripsi' => $deskripsi,
                'icon' => $icon
            );
            $this->M_Nivel->aumentanvl($data);
            $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert"><strong>Atensaun</strong>Dadus Nivel Ensino halot ho Successu.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>');
            redirect('administrator/nivel');
        }
    }

    public function editnvl($id_nivel)
    {
        $this->form_validation->set_rules('nivel_ensino', 'nivel', 'required|trim|is_unique[tbl_nivel.nivel_ensino]', ['is_unique' => 'Posto registo tiha ona']);
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required|trim');
        if ($this->form_validation->run() == false) {
            // $this->load->model('M_Nivel', 'nivel');
            $nivel = $this->M_Nivel->detail($id_nivel);
            $data = array('nivel' => $nivel);
            $data['titlu'] = 'Administrator | Nivel Ensino';
            $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();

            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar', $data);
            $this->load->view('administrator/nivel/editnvl', $data);
            $this->load->view('template/footer');
        } else {

            $nivel_ensino  = htmlspecialchars($this->input->post('nivel_ensino', true));
            $deskripsi = htmlspecialchars($this->input->post('deskripsi', true));
            $icon = $_FILES['icon']['name'];
            if ($icon = '') {
            } else {
                $config['upload_path']          = './assets/img/marker/';
                $config['allowed_types']        = 'jpg|png';

                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('icon')) {
                    $this->session->set_flashdata('message', '<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>Atensaun</strong>Imagen Upload Filha.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>');
                    redirect('administrator/editnvl');
                } else {
                    $icon = $this->upload->data('file_name');
                }
            }

            $data = array(
                'id_nivel' => $id_nivel,
                'nivel_ensino ' => $nivel_ensino,
                'deskripsi' => $deskripsi,
                'icon' => $icon
            );
            $this->M_Nivel->editnvl($data);
            $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert"><strong>Atensaun</strong>Dadus Nivel Ensino halot ho Successu.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>');
            redirect('administrator/nivel');
        }
    }

    public function hamosnvl($id_nivel)
    {
        // $data = array('id_nivel' => $id_nivel);
        // $this->M_Nivel->hamosnvl($data); // Panggil fungsi delete dari model
        // $this->session->set_flashdata('message', '<div class="alert alert-danger " role="alert " > Dadus Hamos ho succeso!</div>');

        // redirect('administrator/nivel');
        $_id = $this->db->get_where('tbl_nivel', ['id_nivel' => $id_nivel])->row();
        $query = $this->db->delete('tbl_nivel', ['id_nivel' => $id_nivel]);
        if ($query) {
            unlink("./assets/img/marker/" . $_id->icon);
        }
        $this->session->set_flashdata('message', '<div class="alert alert-danger alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hid_nivelden="true">&times;</button>
                  <h5><i class="icon fas fa-check"></i> Alert!</h5>
                 Dadus Hamos ho Succeso.
                </div>');

        redirect('administrator/nivel');
    }

    // controller Kategori
    public function kategori()
    {
        $this->load->model('M_Kategori', 'kategori');
        $kategori = $this->M_Kategori->get_kategori();
        $data = array('kategori' => $kategori);
        $data['titlu'] = 'Administrator || Dashboard';
        $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('template/header', $data);
        $this->load->view('template/navbar');
        $this->load->view('template/sidebar', $data);
        $this->load->view('administrator/kategori/kategori', $data);
        $this->load->view('template/footer');
    }

    public function aumentaktg()
    {
        $this->form_validation->set_rules('kategori', 'Kategori', 'required|trim|is_unique[tbl_kategori.kategori]', ['is_unique' => 'Municipio registo tiha ona']);
        // $this->form_validation->set_rules('foto', 'Nivel', 'requider|trim');

        $this->form_validation->set_message('required', 'Favor Prienxe %s labele husik mamuk');
        if ($this->form_validation->run() == false) {
            $data['titlu'] = 'Administrator | Kategori';
            $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar', $data);
            $this->load->view('administrator/kategori/aumentaktg');
            $this->load->view('template/footer');
        } else {

            $data = [
                'kategori ' => htmlspecialchars($this->input->post('kategori', true))
                //'icon' => htmlspecialchars($this->input->post('icon', true))

            ];
            $this->M_Kategori->aumentaktg($data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Dadus kategori halot ho succeso!</div>');
            redirect('administrator/kategori');
        }
    }

    public function editktg($id_kategori)
    {
        $this->form_validation->set_rules('kategori', 'kategori', 'required|trim|is_unique[tbl_kategori.kategori]', ['is_unique' => 'Municipio registo tiha ona']);
        // $this->form_validation->set_rules('foto', 'Nivel', 'requider|trim');

        $this->form_validation->set_message('required', 'Favor Prienxe %s labele husik mamuk');
        if ($this->form_validation->run() == false) {
            $data['titlu'] = 'Administrator | kategori';
            $data['user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
            $kategori = $this->M_Kategori->detail($id_kategori);
            $dadus = array('kategori' => $kategori,);
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar', $data);
            $this->load->view('administrator/kategori/editktg', $dadus);
            $this->load->view('template/footer');
        } else {

            $data = [
                'id_kategori' => $id_kategori,
                'kategori ' => htmlspecialchars($this->input->post('kategori', true))
                //'icon' => htmlspecialchars($this->input->post('icon', true))

            ];
            $this->M_Kategori->editktg($data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Dadus kategori halot ho succeso!</div>');
            redirect('administrator/kategori');
        }
    }

    public function hamosktg($id_kategori)
    {
        $data = array('id_kategori' => $id_kategori);
        $this->M_Kategori->hamosktg($data); // Panggil fungsi delete dari model
        $this->session->set_flashdata('message', '<div class="alert alert-danger " role="alert " > Dadus Hamos ho succeso!</div>');

        redirect('administrator/kategori');
    }

    public function escola()
    {
        $this->load->model('M_Escola', 'escola');
        $escola = $this->M_Escola->get_escola();
        $data = array('escola' => $escola);
        $data['titlu'] = 'Administrator || Dadus Escola';
        $this->load->view('template/header', $data);
        $this->load->view('template/navbar');
        $this->load->view('template/sidebar', $data);
        $this->load->view('administrator/escola/escola', $data);
        $this->load->view('template/footer');
    }

    public function aumentaesc()
    {
        $this->form_validation->set_rules('naran_escola', 'Naran Escola', 'required|trim|is_unique[tbl_escola.naran_escola]', ['is_unique' => 'Naran Escola registo tiha ona']);
        $this->form_validation->set_rules('id_nivel', 'Nivel', 'required|trim');
        $this->form_validation->set_rules('id_kategori', 'Kategori', 'required|trim');
        $this->form_validation->set_rules('id_munisipio', 'Municipio', 'required|trim');
        $this->form_validation->set_rules('id_posto', 'Posto', 'required|trim');
        $this->form_validation->set_rules('nu_tlf', 'Numero telfone', 'required|trim');
        $this->form_validation->set_rules('enderso', 'Enderso', 'required|trim');
        $this->form_validation->set_rules('latitude', 'Latitude', 'required|trim');
        $this->form_validation->set_rules('longitude', 'Longitude', 'required|trim');
        $this->form_validation->set_message('required', 'Favor Prienxe %s labele husik mamuk');

        if ($this->form_validation->run() == false) {
            $kategori = $this->M_Kategori->get_kategori();
            $nivel = $this->M_Nivel->get_nivel();
            $munisipio = $this->M_Munisipio->get_munisipio();
            $dadus = array(
                'kategori' => $kategori,
                'nivel' => $nivel,
                'munisipio' => $munisipio
            );
            $data['titlu'] = 'Administrator || Dadus Escola';
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar');
            $this->load->view('administrator/escola/aumentaesc', $dadus);
            $this->load->view('template/footer');
        } else {

            $naran_escola  = $this->input->post('naran_escola', true);
            $id_nivel = $this->input->post('id_nivel', true);
            $id_kategori = $this->input->post('id_kategori', true);
            $id_munisipio = $this->input->post('id_munisipio', true);
            $id_posto = $this->input->post('id_posto', true);
            $nu_tlf = $this->input->post('nu_tlf', true);
            $enderso = $this->input->post('enderso', true);
            $latitude = $this->input->post('latitude', true);
            $longitude = $this->input->post('longitude', true);
            $data = array(

                'naran_escola ' => $naran_escola,
                'id_nivel' => $id_nivel,
                'id_kategori' => $id_kategori,
                'id_munisipio' => $id_munisipio,
                'id_posto' => $id_posto,
                'nu_tlf' => $nu_tlf,
                'enderso' => $enderso,
                'latitude' => $latitude,
                'longitude' => $longitude
                // 'info_geral' => $info_geral,
                // 'foto' => $foto
            );
            $this->M_Escola->aumentaesc($data);
            $this->session->set_flashdata('message', ' <div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h5><i class="icon fas fa-check"></i> Alert!</h5>
                 Dadus Halot ho Succeso.
                </div>');
            redirect('administrator/escola');
        }
    }

    public function editesc($id_escola)
    {
        $this->form_validation->set_rules('naran_escola', 'Naran Escola', 'required|trim|is_unique[tbl_escola.naran_escola]', ['is_unique' => 'Naran Escola registo tiha ona']);
        $this->form_validation->set_rules('id_nivel', 'Nivel', 'required|trim');
        $this->form_validation->set_rules('id_kategori', 'Kategori', 'required|trim');
        $this->form_validation->set_rules('id_munisipio', 'Municipio', 'required|trim');
        $this->form_validation->set_rules('id_posto', 'Posto', 'required|trim');
        $this->form_validation->set_rules('nu_tlf', 'Numero telfone', 'required|trim');
        $this->form_validation->set_rules('enderso', 'Enderso', 'required|trim');
        $this->form_validation->set_rules('latitude', 'Latitude', 'required|trim');
        $this->form_validation->set_rules('longitude', 'Longitude', 'required|trim');
        $this->form_validation->set_message('required', 'Favor Prienxe %s labele husik mamuk');

        if ($this->form_validation->run() == false) {
            $kategori = $this->M_Kategori->get_kategori();
            $nivel = $this->M_Nivel->get_nivel();
            $munisipio = $this->M_Munisipio->get_munisipio();
            $escola = $this->M_Escola->detail($id_escola);
            $dadus = array(
                'kategori' => $kategori,
                'nivel' => $nivel,
                'munisipio' => $munisipio,
                'escola' => $escola
            );
            $data['titlu'] = 'Administrator || Hadia Dadus Escola';
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar');
            $this->load->view('template/sidebar');
            $this->load->view('administrator/escola/editesc', $dadus);
            $this->load->view('template/footer');
        } else {


            $data = [
                'id_escola' => $id_escola,
                'naran_escola ' => htmlspecialchars($this->input->post('naran_escola', true)),
                'id_nivel' => htmlspecialchars($this->input->post('id_nivel', true)),
                'id_kategori' => htmlspecialchars($this->input->post('id_kategori', true)),
                'id_munisipio' => htmlspecialchars($this->input->post('id_munisipio', true)),
                'nu_tlf' => htmlspecialchars($this->input->post('nu_tlf', true)),
                'enderso' => htmlspecialchars($this->input->post('enderso', true)),
                'latitude' => htmlspecialchars($this->input->post('latitude', true)),
                'longitude' => htmlspecialchars($this->input->post('longitude', true))




            ];
            $this->M_Escola->editesc($data);
            $this->session->set_flashdata('message', ' <div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h5><i class="icon fas fa-check"></i> Alert!</h5>
                 Dadus hadia ho Succeso.
                </div>');
            redirect('administrator/escola');
        }
    }

    public function hamosesc($id_escola)
    {
        $_id = $this->db->get_where('tbl_escola', ['id_escola' => $id_escola])->row();
        $query = $this->db->delete('tbl_escola', ['id_escola' => $id_escola]);
        if ($query) {
            unlink("./assets/galery/" . $_id->foto);
        }
        $this->session->set_flashdata('message', '<div class="alert alert-danger alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h5><i class="icon fas fa-check"></i> Alert!</h5>
                 Dadus Hamos ho Succeso.
                </div>');

        redirect('administrator/escola');
    }

    function get_posto()
    {
        $id = $this->input->post('id');
        $data = $this->M_Escola->get_posto($id);
        echo json_encode($data);
    }
}

/* End of file Administrator.php */