<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Menu extends CI_Controller
{
}



/* End of file Menu.php */