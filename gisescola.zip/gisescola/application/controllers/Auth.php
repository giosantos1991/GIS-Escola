<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }
    public function index()
    {
        if ($this->session->userdata('email')) {
            redirect('member');
        }
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        $this->form_validation->set_message('required', 'Favor Prienxe %s labele husik mamuk');
        $this->form_validation->set_message('valid_email', 'Favor Prienxe {field} valido');

        if ($this->form_validation->run() == false) {

            $data['titlu'] = 'Login Gis Escola';
            $this->load->view('template/header_auth', $data);
            $this->load->view('auth/login');
            $this->load->view('template/footer_auth');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $tbl_user = $this->db->get_where('tbl_user', ['email' => $email])->row_array();

            if ($tbl_user) {
                if ($tbl_user['is_active'] == 1) {
                    if (password_verify($password, $tbl_user['password'])) {
                        $data = [
                            'email' => $tbl_user['email'],
                            'role_id' => $tbl_user['role_id']
                        ];
                        $this->session->set_userdata($data);
                        if ($tbl_user['role_id'] == 1) {
                            redirect('administrator');
                        } else {
                            redirect('member');
                        }
                    } else {
                        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Sala!</div>');
                        redirect('auth');
                    }
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email nee seidauk Activo!</div>');
                    redirect('auth');
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email nee seidauk registo!</div>');
                redirect('auth');
            }
        }
    }

    public function registo()
    {
        if ($this->session->userdata('email')) {
            redirect('member');
        }
        $this->form_validation->set_rules('naran_kompleto', 'Naran', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[tbl_user.email]', ['is_unique' => 'Email nee registo tiha ona']);

        $this->form_validation->set_rules('password1', 'Password', 'trim|required|min_length[5]|matches[password2]', ['matches' => 'Password sala', 'min_length' => 'Password karater la too ']);
        $this->form_validation->set_rules('password2', 'Password', 'trim|required|matches[password1]');

        if ($this->form_validation->run() == false) {
            $data['titlu'] = 'Regiato Akun || Gis Escola';
            $this->load->view('template/header_auth', $data);
            $this->load->view('auth/Registo');
            $this->load->view('template/footer_auth');
        } else {
            $email = $this->input->post('email', true);
            $data = [
                'naran_kompleto ' => htmlspecialchars($this->input->post('naran_kompleto', true)),
                'email' => htmlspecialchars($email),
                'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
                'role_id' => 1,
                'is_active' => 0,
                'date_created' => time(),
                'image' => 'default.jpg'
            ];
            $this->M_Auth->registo($data);
            // $this->db->insert('tbl_user', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Parabens akun registo ho succeso!</div>');
            redirect('auth');
        }
    }


    public function logout()
    {
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('role_id');

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Ita boot Sai ona !</div>');
        redirect('auth');
    }
}
 
 /* End of file Auth.php */