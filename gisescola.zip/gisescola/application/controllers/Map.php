<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Map extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_Munisipio');
    }
    public function index()
    {
        $this->load->model('M_Escola', 'escola');
        $escola = $this->M_Escola->get_escola();
        $data = array('escola' => $escola);
        $data['title'] = ' Gis Escola  Municipio Dili';
        $this->load->view('template/fontend/header', $data);
        $this->load->view('template/fontend/sitebar');
        $this->load->view('map', $data);
        $this->load->view('template/fontend/footer');
    }

    public function detail($id_escola)
    {
        $this->load->model('M_Escola', 'escola');
        $escola = $this->M_Escola->get_escola();
        $data = array('escola' => $escola);
        $data['title'] = ' Gis Escola  Municipio Dili';
        $this->load->view('template/fontend/header', $data);
        $this->load->view('template/fontend/sitebar');
        $this->load->view('detail', $data);
        $this->load->view('template/fontend/footer');
    }
}

/* End of file Map.php */