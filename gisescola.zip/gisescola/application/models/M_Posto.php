<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_Posto extends CI_Model
{

    function get_posto()
    {
        $this->db->from('tbl_posto');
        $this->db->select('tbl_posto.*, tbl_munisipio.id_munisipio AS id_munisipio, tbl_munisipio.munisipio');
        $this->db->join('tbl_munisipio', 'tbl_posto.id_munisipio = tbl_munisipio.id_munisipio');
        $this->db->order_by('munisipio', 'ASC');
        return $this->db->get()->result();
    }

    public function detail($id_posto)
    {
        $this->db->from('tbl_posto');
        $this->db->select('tbl_posto.*, tbl_munisipio.id_munisipio AS id_munisipio, tbl_munisipio.munisipio');
        $this->db->join('tbl_munisipio', 'tbl_posto.id_munisipio = tbl_munisipio.id_munisipio');
        $this->db->where('id_posto', $id_posto);
        return $this->db->get()->row();
    }
    public function editpst($data)
    {
        $this->db->where('id_posto', $data['id_posto']);
        $this->db->update('tbl_posto', $data);
    }
    public function aumentapst($data)
    {

        $this->db->insert('tbl_posto', $data);
    }

    public function hamospst($data)
    {

        $this->db->where('id_posto', $data['id_posto']);
        $this->db->delete('tbl_posto', $data);
    }

    function posto($id_posto)
    {
        $hasil = $this->db->query("SELECT * FROM tbl_posto WHERE id_munisipio='$id_posto'");
        return $hasil->result();
    }
}