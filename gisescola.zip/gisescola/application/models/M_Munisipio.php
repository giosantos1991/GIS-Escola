<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_Munisipio extends CI_Model
{

    public function aumentamsp($data)
    {
        $this->db->insert('tbl_munisipio', $data);
    }

    public function get_munisipio()
    {
        $this->db->select('*');
        $this->db->from('tbl_munisipio');
        return $this->db->get()->result();
    }

    public function detail($id_munisipio)
    {
        $this->db->select('*');
        $this->db->from('tbl_munisipio');
        $this->db->where('id_munisipio', $id_munisipio);
        return $this->db->get()->row();
    }

    public function editmsp($data)
    {
        $this->db->where('id_munisipio', $data['id_munisipio']);
        $this->db->update('tbl_munisipio', $data);
    }

    public function hamosmsp($data)
    {

        $this->db->where('id_munisipio', $data['id_munisipio']);
        $this->db->delete('tbl_munisipio', $data);
    }
}