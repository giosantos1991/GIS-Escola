<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_Auth extends CI_Model
{
    public function registo($data)
    {

        $this->db->insert('tbl_user', $data);
    }
}