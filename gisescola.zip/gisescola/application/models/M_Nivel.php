<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_Nivel extends CI_Model
{
    public function aumentanvl($data)
    {

        $this->db->insert('tbl_nivel', $data);
    }

    public function get_nivel()
    {

        $this->db->select('*');
        $this->db->from('tbl_nivel');
        $this->db->order_by('nivel_ensino', 'asc');

        return $this->db->get()->result();
    }

    public function detail($id_nivel)
    {

        $this->db->select('*');
        $this->db->from('tbl_nivel');
        $this->db->where('id_nivel', $id_nivel);
        return $this->db->get()->row();
    }

    public function editnvl($data)
    {
        $this->db->where('id_nivel', $data['id_nivel']);
        $this->db->update('tbl_nivel', $data);
    }

    // public function hamosnvl($data)
    // {

    //     $this->db->where('id_nivel', $data['id_nivel']);
    //     $this->db->delete('tbl_nivel', $data);

    //     $_id = $this->db->get_where('tb_escola', ['id_nivel' => $id_nivel])->row();
    //     $query = $this->db->delete('tb_escola', ['id_nivel' => $id_nivel]);
    //     if ($query) {
    //         unlink("./assets/galery/" . $_id->icon);
    //     }
    // }
}