<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_Escola extends CI_Model
{
    public function get_escola()
    {
        $this->db->from('tbl_escola');
        $this->db->select(
            'tbl_escola.*, tbl_nivel.id_nivel AS id_nivel, tbl_nivel.nivel_ensino,tbl_nivel.icon,
            tbl_kategori.id_kategori AS id_kategori, tbl_kategori.kategori, 
            tbl_munisipio.id_munisipio AS id_munisipio, tbl_munisipio.munisipio,
            tbl_posto.id_posto AS id_posto, tbl_posto.posto'
        );
        $this->db->join('tbl_nivel', 'tbl_escola.id_nivel = tbl_nivel.id_nivel');
        $this->db->join('tbl_kategori', 'tbl_escola.id_kategori = tbl_kategori.id_kategori');
        $this->db->join('tbl_munisipio', 'tbl_escola.id_munisipio = tbl_munisipio.id_munisipio');
        $this->db->join('tbl_posto', 'tbl_escola.id_posto = tbl_posto.id_posto');
        return $this->db->get()->result();
    }
    public function detail($id_escola)
    {
        $this->db->from('tbl_escola');
        $this->db->select(
            'tbl_escola.*, tbl_nivel.id_nivel AS id_nivel, tbl_nivel.nivel_ensino,tbl_nivel.icon,
            tbl_kategori.id_kategori AS id_kategori, tbl_kategori.kategori, 
            tbl_munisipio.id_munisipio AS id_munisipio, tbl_munisipio.munisipio,
            tbl_posto.id_posto AS id_posto, tbl_posto.posto'
        );
        $this->db->join('tbl_nivel', 'tbl_escola.id_nivel = tbl_nivel.id_nivel');
        $this->db->join('tbl_kategori', 'tbl_escola.id_kategori = tbl_kategori.id_kategori');
        $this->db->join('tbl_munisipio', 'tbl_escola.id_munisipio = tbl_munisipio.id_munisipio');
        $this->db->join('tbl_posto', 'tbl_escola.id_posto = tbl_posto.id_posto');
        $this->db->where('id_escola', $id_escola);
        return $this->db->get()->row();
    }

    public function editesc($data)
    {
        $this->db->where('id_escola', $data['id_escola']);
        $this->db->update('tbl_escola', $data);
    }
    public function aumentaesc($data)
    {
        $this->db->insert('tbl_escola', $data);
    }


    function get_posto($id)
    {
        $hasil = $this->db->query("SELECT * FROM tbl_posto WHERE id_munisipio='$id'");
        return $hasil->result();
    }
}