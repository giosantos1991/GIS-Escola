<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_Kategori extends CI_Model
{

    public function aumentaktg($data)
    {
        $this->db->insert('tbl_kategori', $data);
    }

    public function get_kategori()
    {
        $this->db->select('*');
        $this->db->from('tbl_kategori');
        return $this->db->get()->result();
    }

    public function detail($id_kategori)
    {
        $this->db->select('*');
        $this->db->from('tbl_kategori');
        $this->db->where('id_kategori', $id_kategori);
        return $this->db->get()->row();
    }

    public function editktg($data)
    {
        $this->db->where('id_kategori', $data['id_kategori']);
        $this->db->update('tbl_kategori', $data);
    }

    public function hamosktg($data)
    {

        $this->db->where('id_kategori', $data['id_kategori']);
        $this->db->delete('tbl_kategori', $data);
    }
}