<!---copy-right ---->
<div class="copy-right">
    <div class="container">

        <div class="footer-social-icons wow fadeInDown animated animated" data-wow-delay=".5s"
            style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
            <ul>
                <li><a class="facebook" href="https://www.facebook.com/" target="_blank"><span>Facebook</span></a></li>
                <li><a class="whatsapp" href="https://api.whatsapp.com/send?phone=67078686052&text=bro diak ka lae"
                        target="_blank"><span>whatsapp</span></a></li>
                <li><a class="flickr" href="#"><span>Flickr</span></a></li>
                <li><a class="googleplus" href="#"><span>Google+</span></a></li>
                <li><a class="dribbble" href="#"><span>Dribbble</span></a></li>
            </ul>
        </div>
        <p class="wow zoomIn animated animated" data-wow-delay=".5s"
            style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">© <?= date('Y'); ?> Eligio dos
            Santos . All Rights
            Reserved </p>
    </div>
</div>
<!--- /copy-right ---->
<!-- DataTables -->
<script src="<?= base_url('assets/') ?>plugins/datatables/jquery.dataTables.js"></script>
<script src="<?= base_url('assets/') ?>plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<script>
$(function() {
    $("#example1").DataTable();
    $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
    });
});
</script>
</body>

</html>