<!DOCTYPE HTML>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= $title; ?></title>
    <link rel="shortcut icon" href="<?= base_url('assets/') ?>img/map.png">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script type="applijewelleryion/x-javascript">
        addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
    </script>
    <link href="<?= base_url('assets') ?>/font-end/css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="<?= base_url('assets') ?>/font-end/css/style.css" rel='stylesheet' type='text/css' />
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
    <link href="<?= base_url('assets') ?>/font-end/css/font-awesome.css" rel="stylesheet">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?= base_url('assets/') ?>plugins/datatables-bs4/css/dataTables.bootstrap4.css">
    <!-- Custom Theme files -->
    <script src="<?= base_url('assets') ?>/font-end/js/jquery-1.12.0.min.js"></script>
    <script src="<?= base_url('assets') ?>/font-end/js/bootstrap.min.js"></script>
    <!--animate-->
    <link href="<?= base_url('assets') ?>/font-end/css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="<?= base_url('assets') ?>/font-end/js/wow.min.js"></script>
    <script>
    new WOW().init();
    </script>
    <!--//end-animate-->

    <!-- leaflet -->
    <script src="//code.jquery.com/jquery-1.11.2.min.js"></script>

    <link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css" />

    <script src="http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js"></script>

    <!-- 
<script src="https://api.mapbox.com/mapbox-gl-js/v2.0.1/mapbox-gl.js"></script>
<link href="https://api.mapbox.com/mapbox-gl-js/v2.0.1/mapbox-gl.css" rel="stylesheet" />
<style>

	#map {height: 500%; }
</style> -->

</head>

<body>