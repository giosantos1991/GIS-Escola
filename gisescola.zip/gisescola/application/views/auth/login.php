<div class="login-box">
    <!-- /.login-logo -->
    <div class="card card-outline card-primary">
        <div class="card-header text-center">
            <h2> <i class="fas fa-map-marked-alt"> Gis <span>Escola</span> </i> </h2>
        </div>
        <div class="card-body">

            <?= $this->session->flashdata('message'); ?>
            <form action="<?= base_url('auth') ?>" method="post">
                <?= form_error('email', '<small class="text-danger pl-3">', '</small>') ?>
                <div class="input-group mb-3 <?= form_error('email') ? 'has-error' : null ?>">
                    <input type="email" name="email" class="form-control" placeholder="Email" autofocus=""
                        autocomplete="off" value="<?= set_value('email'); ?>">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                        </div>
                    </div>

                </div>
                <?= form_error('password', '<small class="text-danger pl-3">', '</small>') ?>
                <div class="input-group mb-3 <?= form_error('password') ? 'has-error' : null ?>">
                    <input type="password" name="password" id="password" autocomplete="off" class="form-control"
                        placeholder="Password">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-8">

                    </div>
                    <!-- /.col -->
                    <div class="col-4">
                        <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>



            <!-- /.social-auth-links -->

            <p class="mb-1">
                <a href="<?= base_url('') ?>">Fila Ba website Mapa Escola</a>
            </p>
            <!-- <p class="mb-0">
                <a href="<?= base_url('auth/registo') ?>" class="text-center">Register a new membership</a>
            </p> -->
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<!-- /.l