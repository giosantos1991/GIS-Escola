<div class="about">
    <div class="  wow zoomIn animated animated" data-wow-delay=".5s"
        style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">
        <div class="container">

            <div class="row">
                <h3>Mapa Escola</h3>

                <div class="col-md-12">
                    <div id="mapid" style="height: 500px;"></div>
                </div>
            </div>



        </div>
    </div>
</div>

<script>
var mymap = L.map('mapid').setView([-8.5563299, 125.534907], 13);
L.tileLayer(
    'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
            '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
            'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        id: 'mapbox/satellite-v9'
    }).addTo(mymap);
<?php foreach ($escola as $esc) { ?>
var icon_escola = L.icon({
    iconUrl: '<?= base_url('assets/img/marker/') . $esc->icon ?>',
    iconSize: [30, 35],

});

L.marker([<?= $esc->latitude ?>, <?= $esc->longitude ?>], {
        icon: icon_escola
    }).addTo(mymap)
    .bindPopup(
        "<b>Naran Escola</b> : <?= $esc->naran_escola ?> <br>" +
        " <b>Naran Escola</b> : <?= $esc->nivel_ensino ?> <br>" +
        " <b>Kategori Escola</b> : <?= $esc->kategori ?> <br> " +
        "<b> Munisipio</b> : <?= $esc->munisipio ?> <br>" +
        "<b> Posto</b> : <?= $esc->posto ?> <br>" +
        "<b> Nu.Telfone</b> : <?= $esc->nu_tlf ?> <br>" +
        "<b> Enderso</b> : <?= $esc->enderso ?> <br>" +
        "<b> Latitude</b> : <?= $esc->latitude ?> <br>" +
        "<b> Longitude</b> : <?= $esc->longitude ?><br><br>"
        // "<a href=' <?= base_url('map/detail/') . $esc->id_escola ?>' class='btn btn-warning'> Detail</a>"



    );
<?php } ?>
</script>