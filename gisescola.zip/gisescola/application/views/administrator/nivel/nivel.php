<div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content ">
        <div class="container-fluid">
            <div class="row mt-5">
                <div class="col-12">
                    <?= $this->session->flashdata('message'); ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Dadus Nivel Ensino</h3>

                        </div>
                        <!-- /.card-header -->

                        <div class="card-body">
                            <a href="<?= base_url('administrator/aumentanvl') ?>" class="btn btn-success mb-2"> <i
                                    class="fas fa-plus"></i> </a>

                            <table id="example1" class="table table-bordered table-striped mb-2">
                                <thead>
                                    <tr>
                                        <th>Nu</th>
                                        <th>Kode Nivel</th>
                                        <th>Nivel Ensino</th>
                                        <th>Icon</th>
                                        <th>Aksaun</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;
                                    foreach ($nivel as $nvl) { ?>
                                    <tr>
                                        <td width="10px"><?= $no++; ?></td>
                                        <td><?= $nvl->nivel_ensino ?></td>
                                        <td><?= $nvl->deskripsi ?></td>
                                        <td> <img src="<?= base_url('assets/img/marker/') . $nvl->icon ?>" alt=""
                                                width="25"> </td>


                                        <td>
                                            <a href="<?= base_url('administrator/editnvl/' . $nvl->id_nivel) ?>"
                                                class="btn btn-info btn-sm"> <i class="fa fa-edit"></i> </a>
                                            <a href="<?= base_url('administrator/hamosnvl/' . $nvl->id_nivel) ?>"
                                                class="btn btn-danger btn-sm"
                                                onclick="return confirm('hakarak Hamos dadus nee')"> <i
                                                    class="fa fa-trash"></i> </a>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>

                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>