<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <div class="row mt-5">
                <div class="col-12">
                    <?= $this->session->flashdata('message'); ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Dadus Munisipio</h3>
                        </div>
                        <div class="card-body">
                            <a href="<?= base_url('administrator/aumentamsp') ?>" class="btn btn-success mb-2"> <i
                                    class="fas fa-plus"></i> </a>
                            <table id="example1" class="table table-bordered table-striped mb-2">
                                <thead>
                                    <tr>
                                        <th>Nu</th>
                                        <th>Munisipio</th>
                                        <th>Aksaun</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;
                                    foreach ($munisipio as $msp) { ?>
                                    <tr>
                                        <td width="10px"><?= $no++; ?></td>
                                        <td><?= $msp->munisipio ?></td>
                                        <td>
                                            <a href="<?= base_url('administrator/editmsp/' . $msp->id_munisipio) ?>"
                                                class="btn btn-info btn-sm"> <i class="fa fa-edit"></i> </a>
                                            <a href="<?= base_url('administrator/hamosmsp/' . $msp->id_munisipio) ?>"
                                                class="btn btn-danger btn-sm"
                                                onclick="return confirm('hakarak Hamos dadus nee')"> <i
                                                    class="fa fa-trash"></i> </a>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>