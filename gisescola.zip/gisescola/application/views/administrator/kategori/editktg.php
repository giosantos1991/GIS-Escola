<div class="content-wrapper">

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid ">
            <div class="row mt-5">
                <!-- left column -->
                <div class="col-md-6 mx-auto">
                    <!-- general form elements -->
                    <div class="card card-primary ">
                        <div class="card-header">
                            <h3 class="card-title">Hadia Dadus</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form action="<?= base_url('administrator/editktg/' . $kategori->id_kategori) ?>" method="post">
                            <div class="card-body">

                                <div class="form-group">
                                    <label>Kategori Escola</label>
                                    <input type="text" name="kategori" id="kategori" class="form-control"
                                        placeholder="kategori" autocomplete="off" autofocus=""
                                        value="<?= $kategori->kategori ?>"
                                        onkeyup="this.value=this.value.toUpperCase()">
                                    <?= form_error('kategori', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>

                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i>Halot</button>
                                <a href="<?= base_url('administrator/kategori') ?>" class="btn btn-warning"> <i
                                        class="fa fa-undo"></i>Fila</a>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.card -->
            </div>
            <!--/.col (right) -->
        </div>
        <!-- /.row -->
</div><!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>