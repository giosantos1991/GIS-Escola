<div class="content-wrapper">


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid ">
            <div class="row mt-5">
                <!-- left column -->
                <div class="col-md-6 mx-auto">
                    <!-- general form elements -->
                    <div class="card card-primary ">
                        <div class="card-header">
                            <h3 class="card-title">Prinse Dadus</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form action="<?= base_url('administrator/aumentapst') ?>" method="post">
                            <div class="card-body">

                                <div class="form-group">
                                    <label> Munisipio</label>
                                    <select name="id_munisipio" id="id_munisipio" class="form-control">
                                        <option value="">Hili Munisipio </option>
                                        <?php foreach ($munisipio as $msp) { ?>
                                        <option value="<?= $msp->id_munisipio ?>"><?= $msp->munisipio ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Posto Administrativo</label>
                                    <input type="text" name="posto" id="posto" class="form-control"
                                        placeholder="Posto Administrativo" autocomplete="off"
                                        value="<?= set_value('posto') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                </div>


                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i>Halot</button>
                                <a href="<?= base_url('administrator/pst') ?>" class="btn btn-warning"> <i
                                        class="fa fa-undo"></i>Fila</a>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.card -->
            </div>
            <!--/.col (right) -->
        </div>
        <!-- /.row -->
</div><!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>