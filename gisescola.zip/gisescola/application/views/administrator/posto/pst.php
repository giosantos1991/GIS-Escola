<div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content ">
        <div class="container-fluid">
            <div class="row mt-5">
                <div class="col-12">
                    <?= $this->session->flashdata('message'); ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Dadus Posto Administrativo</h3>

                        </div>
                        <!-- /.card-header -->

                        <div class="card-body">
                            <a href="<?= base_url('administrator/aumentapst') ?>" class="btn btn-success mb-2"> <i
                                    class="fas fa-plus"></i> </a>

                            <table id="example1" class="table table-bordered table-striped mb-2">
                                <thead>
                                    <tr>
                                        <th>Nu</th>
                                        <th>Munisipio</th>
                                        <th>Posto</th>
                                        <th>Aksaun</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;
                                    foreach ($posto as $pst) { ?>
                                    <tr>
                                        <td width="10px"><?= $no++; ?></td>
                                        <td><?= $pst->munisipio ?></td>
                                        <td><?= $pst->posto ?></td>


                                        <td>
                                            <a href="<?= base_url('administrator/editpst/' . $pst->id_posto) ?>"
                                                class="btn btn-info btn-sm"> <i class="fa fa-edit"></i> </a>
                                            <a href="<?= base_url('administrator/hamospst/' . $pst->id_posto) ?>"
                                                class="btn btn-danger btn-sm"
                                                onclick="return confirm('hakarak Hamos dadus nee')"> <i
                                                    class="fa fa-trash"></i> </a>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>

                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>