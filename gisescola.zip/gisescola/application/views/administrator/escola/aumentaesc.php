<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <div class="row mt-5">
                <!-- left column -->
                <div class="col-md-6">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header bg-blue">
                            <h3 class="card-title"> Prinse Dadus Escola</h3>
                        </div>

                        <form action="<?= base_url('administrator/aumentaesc') ?>" method="post"
                            enctype="multipart/form-data">
                            <div class="card-body">
                                <div class="from-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label> Naran Escola</label>
                                            <input type="text" name="naran_escola" autocomplete="off"
                                                class="form-control" autofocus="" placeholder="Prinse Naran Escola"
                                                value="<?= set_value('naran_escola') ?>"
                                                onkeyup="this.value=this.value.toUpperCase()">
                                            <?= form_error('naran_escola', '<small class="text-danger pl-3">', '</small>') ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="from-group">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Nivel Ensino</label>
                                            <select name="id_nivel" id="id_nivel" class="form-control">
                                                <option value="0">Hili Nivel Ensino</option>
                                                <?php foreach ($nivel as $nvl) { ?>
                                                <option value="<?= $nvl->id_nivel ?>"><?= $nvl->nivel_ensino ?>
                                                </option>
                                                <?php } ?>
                                            </select>
                                            <?= form_error('id_nivel', '<small class="text-danger pl-3">', '</small>') ?>
                                        </div>

                                        <div class="col-md-6">
                                            <label> Kategori</label>
                                            <select name="id_kategori" id="id_kategori" class="form-control">
                                                <option value="0">Hili Kategori</option>

                                                <?php foreach ($kategori as $ktg) { ?>
                                                <option value="<?= $ktg->id_kategori ?>"><?= $ktg->kategori ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="from-group">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Munisipio</label>
                                            <select name="id_munisipio" id="id_munisipio" class="form-control">
                                                <option value="0">Hili Munisipio</option>

                                                <?php foreach ($munisipio as $msp) { ?>
                                                <option value="<?= $msp->id_munisipio ?>"><?= $msp->munisipio ?>
                                                </option>

                                                <?php } ?>
                                            </select>
                                        </div>

                                        <div class="col-md-6">
                                            <label> Posto</label>
                                            <select name="id_posto" id="id_posto" class="id_posto form-control">
                                                <option value="0">Hili Posto</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="from-group">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Nu Telefone</label>
                                            <input type="text" name="nu_tlf" autocomplete="off" class="form-control"
                                                placeholder="Prinse Numeru telefone" value="<?= set_value('nu_tlf') ?>"
                                                onkeyup="this.value=this.value.toUpperCase()">
                                            <?= form_error('nu_tlf', '<small class="text-danger pl-3">', '</small>') ?>
                                        </div>

                                        <div class="col-md-6">
                                            <label>Enderso</label>
                                            <input type="text" name="enderso" autocomplete="off" class="form-control"
                                                value="<?= set_value('enderso') ?>" placeholder="Prinse Enderso"
                                                onkeyup="this.value=this.value.toUpperCase()">
                                            <?= form_error('enderso', '<small class="text-danger pl-3">', '</small>') ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="from-group">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Latitude</label>
                                            <input type="text" id="Latitude" name="latitude" autocomplete="off"
                                                class="form-control" value="<?= set_value('latitude') ?>" readonly="">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Longitude</label>
                                            <input type="text" id="Longitude" name="longitude" autocomplete="off"
                                                class="form-control" value="<?= set_value('longitude') ?>" readonly="">
                                        </div>
                                    </div>
                                </div>


                            </div>


                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary"> <i class="fas fa-save"></i> </button>
                                <a href="<?= base_url('administrator/escola') ?>" class="btn btn-warning"> <i
                                        class="fas fa-undo-alt"></i> </a>
                            </div>
                        </form>
                    </div>

                </div>

                <div class="col-md-6">
                    <!-- Form Element sizes -->
                    <div class="card card-success">
                        <div class="card-header">
                            <h3 class="card-title"> Mapa</h3>
                        </div>
                        <div class="card-body">

                            <div id="mapid" style="height: 400px;"></div>


                        </div>

                    </div>

                </div>

            </div>

        </div>
    </section>

</div>

<script>
var curLocation = [0, 0];
if (curLocation[0] == 0 && curLocation[1] == 0) {
    curLocation = [-8.5563299, 125.534907];
}

var mymap = L.map('mapid').setView([-8.5563299, 125.534907], 13);
L.tileLayer(
    'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
            '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
            'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        id: 'mapbox/satellite-v9'
    }).addTo(mymap);

mymap.attributionControl.setPrefix(false);
var marker = new L.marker(curLocation, {
    draggable: 'true'
});

marker.on('dragend', function(event) {
    var position = marker.getLatLng();
    marker.setLatLng(position, {
        draggable: 'true'
    }).bindPopup(position).update();
    $("#Latitude").val(position.lat);
    $("#Longitude").val(position.lng).keyup();
});

$("#Latitude, #Longitude").change(function() {
    var position = [parseInt($("#Latitude").val()), parseInt($("#Longitude").val())];
    marker.setLatLng(position, {
        draggable: 'true'
    }).bindPopup(position).update();
    mymap.panTo(position);
});
mymap.addLayer(marker);
</script>